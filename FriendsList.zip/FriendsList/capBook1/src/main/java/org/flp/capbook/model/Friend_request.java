package org.flp.capbook.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Friend_request {
	
	
	@Id
	@GeneratedValue
		private Integer friendId;
	/*@OneToOne
		@JoinColumn(name="senderId")*/
		private Integer senderId;
		/*@OneToOne
		@JoinColumn(name="receiverId")*/
		private Integer receiverId;
		private String status="pending"; 
	 

	
	
	public Friend_request() {
		
	}




	public Friend_request(Integer friendId, Integer senderId, Integer receiverId, String status) {
		super();
		this.friendId = friendId;
		this.senderId = senderId;
		this.receiverId = receiverId;
		this.status = status;
	}




	public Integer getFriendId() {
		return friendId;
	}




	public void setFriendId(Integer friendId) {
		this.friendId = friendId;
	}




	public Integer getSenderId() {
		return senderId;
	}




	public void setSenderId(Integer senderId) {
		this.senderId = senderId;
	}




	public Integer getReceiverId() {
		return receiverId;
	}




	public void setReceiverId(Integer receiverId) {
		this.receiverId = receiverId;
	}




	public String getStatus() {
		return status;
	}




	public void setStatus(String status) {
		this.status = status;
	}




	@Override
	public String toString() {
		return "Friend_request [friendId=" + friendId + ", senderId=" + senderId + ", receiverId=" + receiverId
				+ ", status=" + status + "]";
	}

}