package org.flp.capbook.dao;

import java.util.List;


import org.flp.capbook.model.UserProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("userprofiledao")
@Transactional

public interface IUserProfileDao extends JpaRepository<UserProfile,String> {

	List<UserProfile> findAll();

}
