package org.flp.capbook.dao;

import org.flp.capbook.model.Login;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("logindao")
@Transactional


public interface ILoginDao extends JpaRepository<Login,String> {
	
	

}
